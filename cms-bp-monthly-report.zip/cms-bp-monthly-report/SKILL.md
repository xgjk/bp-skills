---
name: bp-monthly-report
description: >-
  BP个人月度汇报生成与发送工具。基于 BP 目标结构、衡量标准和当月汇报证据，
  按分步流程生成结构固定、证据可追溯的月报初稿。
  当用户需要生成、发送或预览个人BP月度汇报时使用。
---

# BP 个人月度汇报

为 BP 系统中的个人节点生成月度汇报。核心逻辑是**先拆证据、再做判断、最后组装报告**。

> **渐进式加载**：启动时只需阅读本文件。各步骤的详细操作说明和参考文档按需加载。

## 目录结构

```
references/
  workflow-details.md            -- 各步骤详细操作说明与接口调用（执行步骤时加载）
  traffic-light-rules.md         -- 灯色判断规则与排除规则（Step 3 加载）
  evidence-rules.md              -- 证据去重、分级、归集与链接规则（Step 3 加载）
  report-template-bp-self-check.md -- 报告模板与输出格式定义（Step 3 加载）
  validation-rules.md            -- 合规校验、语言清洗与附录搬运（Step 3d 加载）
  changelog.md                   -- 变更记录（仅维护参考，无需加载）
scripts/
  monthly_report_api.py          -- API 工具脚本
```

## 核心概念

- **报告定位**：以"每个 BP 目标"为主线底座的自查报告，串起承诺对照→结果→举措→偏差
- **判断主轴**：先以目标维度判断是否参与自查（计划时间范围与汇报月份有无交集），目标不在范围内直接标★未启动；参与自查的目标再对其下关键举措逐个判灯，KR 只做差距分析不判灯
- **灯色层级**：目标级排除判断（★未启动 / 参与）→ 举措级独立判灯 → 目标级从举措聚合（红→黄→黑→绿）→ KR 级不判灯
- **证据编号**：当月 `R{MM}{序号}`（如 `R0301`），上月 `RP{序号}`（如 `RP01`），严禁混用

## 生成流程

**禁止一步生成整篇报告。** 必须按以下步骤顺序执行。

> 执行每个步骤前，读取 [references/workflow-details.md](references/workflow-details.md) 中对应章节获取详细操作说明。

### Step 1: 确定目标员工与月份

获取 `groupId`、`employeeId`、`report_month`。若用户只给姓名，通过 `bp-data-viewer` 定位。

### Step 1.5: 标记生成开始

调用 `update_report_status --status 0` 标记"生成中"。

### Step 2: 采集 BP 数据

| 子步骤 | 操作 | 产出 |
|--------|------|------|
| 2a-i | `collect_monthly_overview` | `/tmp/monthly_overview_{groupId}.json` |
| 2a-ii | 逐目标 `collect_goal_data` | `/tmp/goal_data_{groupId}_{goalId}.json` × N |
| 2b | `collect_previous_month_data` | `/tmp/prev_month_data_{groupId}.json` |

### Step 3: 生成月报内容

> **加载参考文档**：进入 Step 3 前，读取：
> - [references/traffic-light-rules.md](references/traffic-light-rules.md)
> - [references/evidence-rules.md](references/evidence-rules.md)
> - [references/report-template-bp-self-check.md](references/report-template-bp-self-check.md)

必须按 3a → 3b → 3c → 3d 顺序执行，不可跳步。

| 子步骤 | 操作 | 产出 |
|--------|------|------|
| 3a | 构建 BP 锚点图 | `/tmp/bp_anchor_{groupId}.md` |
| 3b | 构建证据台账 + R/RP 编号分配（按 evidence-rules.md） | `/tmp/evidence_ledger_{groupId}.md` |
| 3c | 排除判断 + 逐目标循环（精读→判灯→组装） | `/tmp/goal_cards_{groupId}_{N}.md` + `/tmp/goal_section_{groupId}_{N}.md` |
| 3d | 拼接全局报告 + 语言清洗 + 15项合规校验（加载 [validation-rules.md](references/validation-rules.md)） | `/tmp/report_selfcheck_{groupId}.md` |

### Step 4: 发送 → 保存

校验通过后直接发送（`send_report`），记录 `report_record_id`，再保存到 BP 系统（`save_monthly_report`）。失败时调用 `update_report_status --status 2`。
