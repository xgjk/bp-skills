# 生成流程详细操作手册

> **MANDATORY RULES**
> 本文件包含月报生成流程各步骤的完整操作说明、接口调用方式、数据结构定义和约束条件。
> AI 在执行对应步骤时，必须严格按照本文件的说明操作，不得跳过、简化或自行推断替代方案。

---

## Step 1: 确定目标员工与月份

用户需提供：
- **目标员工**：员工姓名、employeeId 或 groupId（个人分组 ID）
- **汇报月份**：格式 `YYYY-MM`，如 `2026-03`

推荐输入协议：

```yaml
groupId: 2029384010718834690
report_month: 2026-03
```

若用户只给了姓名，通过 `bp-data-viewer` 的 `search_group_by_name` 在个人分组中按名称匹配定位。若没有 `period_id`，用 `get_all_periods` 取 `status=1` 的启用周期。

---

## Step 1.5: 标记生成开始

确定 `groupId` 和月份后，**立即**调用：

```bash
python3 .openclaw/skills/bp-monthly-report/scripts/monthly_report_api.py update_report_status \
  --group_id "{groupId}" \
  --month "{YYYY-MM}" \
  --status 0
```

状态 `0=生成中`。后续任何步骤失败，都必须调用 `update_report_status --status 2 --fail_reason "失败原因"` 记录失败。

---

## Step 2a-i: 采集全局概览

```bash
python3 .openclaw/skills/bp-monthly-report/scripts/monthly_report_api.py collect_monthly_overview \
  --group_id "{groupId}" \
  --month "2026-03" \
  --output "/tmp/monthly_overview_{groupId}.json"
```

**输出 JSON 结构**：

| 字段 | 说明 |
|------|------|
| `taskTree` | 精简后的任务树（目标 → 关键成果 → 关键举措） |
| `goals` | 目标摘要列表，每条含 `goalId`、`name`、`fullLevelNumber`、`planDateRange`、`statusDesc` |
| `stats` | 统计信息：`totalGoals`（目标数）、`totalNodes`（总节点数） |

执行完成后，**Read** 此文件获取目标列表，确定有多少个目标需要逐个采集。

---

## Step 2a-ii: 逐目标采集数据

读取 Step 2a-i 的 `goals` 列表，对每个目标独立采集：

```bash
python3 .openclaw/skills/bp-monthly-report/scripts/monthly_report_api.py collect_goal_data \
  --group_id "{groupId}" \
  --goal_id "{goalId}" \
  --month "2026-03" \
  --output "/tmp/goal_data_{groupId}_{goalId}.json"
```

脚本内部自动完成：
1. 获取该目标的完整详情（含衡量标准、KR、举措、参与人）
2. 提取该目标下所有节点 ID（目标自身 + KR + 举措）
3. 对每个节点查询当月关联汇报列表
4. 拉取所有去重 reportId 的汇报**原文全文**（不截断）
5. 构建该目标内部的反向索引（reportId → taskId 列表）
6. 输出独立 JSON 文件

**输出 JSON 结构**：

| 字段 | 说明 |
|------|------|
| `goalId` | 目标 ID |
| `goalDetail` | 该目标的完整详情（含 KR 列表、举措列表、衡量标准等） |
| `uniqueReportMap` | reportId → 完整汇报内容的去重主表（**不截断**，保留原文全文） |
| `reportTaskMapping` | reportId → 关联的 taskId 列表（仅该目标范围内的反向索引） |
| `reports` | 按 taskId 分组的汇报引用 |
| `stats` | 统计信息：`nodeCount`、`uniqueReportCount`、`fetchedReportContents` |
| `errors` | 采集过程中的错误记录（如有） |

**产出文件一览**：

```
/tmp/monthly_overview_{groupId}.json         -- 全局概览
/tmp/goal_data_{groupId}_{goalId_1}.json     -- 目标1 数据
/tmp/goal_data_{groupId}_{goalId_2}.json     -- 目标2 数据
...
```

---

## Step 2b: 采集上月汇报与评价

```bash
python3 .openclaw/skills/bp-monthly-report/scripts/monthly_report_api.py collect_previous_month_data \
  --group_id "{groupId}" \
  --month "2026-02" \
  --output "/tmp/prev_month_data_{groupId}.json"
```

脚本内部自动完成：
1. 调用 `listMonthlyReports` 获取上月所有月报的 `reportTypeDesc` + `reportRecordId`
2. 对每个 `reportRecordId`，通过工作协同接口拉取汇报正文
3. 调用 `getMonthlyEvaluation` 获取上月评价的翻译后 Markdown（自评 + 上级评价）
4. 将全部数据写入一个聚合 JSON 文件

**输出 JSON 结构**：

| 字段 | 说明 |
|------|------|
| `reports` | 上月各类型月报列表，每条含 `reportTypeDesc`、`reportRecordId`、`title`、`content` |
| `evaluations` | 上月评价 Markdown 列表，每条含 `evaluationTypeDesc`（自评/上级评价）和 `evaluationMarkdown` |
| `stats` | 统计信息：报告数、评价数 |
| `errors` | 采集过程中的错误记录（如有） |

**使用方式**：
- 上月报告正文作为本月汇报的纵向对比基线
- 上月评价 Markdown 中的评分和评语可用于本月灯色判断的辅助参考
- 若上月数据为空（首月汇报），跳过此步骤，不影响后续流程

---

## Step 3a: 构建 BP 锚点图

从 `/tmp/monthly_overview_{groupId}.json` 读取任务树构建全局骨架，从各 `/tmp/goal_data_{groupId}_{goalId}.json` 的 `goalDetail` 中提取每个目标的详情。

对每个目标，提取：
- 目标名称、编号（fullLevelNumber）
- 上级组织 BP 对齐关系（upwardTaskList）
- 下属关键成果列表，每个关键成果提取：
  - 名称、编号
  - **衡量标准**（measureStandard，去除 HTML 标签）
  - 监督人、承接人
  - 计划时间范围（planDateRange）
  - 当前状态（statusDesc）
- 下属关键举措列表，每个举措提取：
  - 名称、编号
  - 计划时间范围（planDateRange）
  - 当前状态（statusDesc）

将此骨架写入 `/tmp/bp_anchor_{groupId}.md`，作为后续判断的锚点。

---

## Step 3b: 构建证据台账（含 R 编号分配）

遍历所有 `/tmp/goal_data_{groupId}_{goalId}.json` 文件，汇总全局汇报数据。R 编号分配必须全局去重。

**严格按 [evidence-rules.md](evidence-rules.md) 执行**以下全部操作：

1. **按 reportId 全局去重**：从所有目标文件的 `uniqueReportMap` 中汇总，同一条汇报只算一次
2. **内容聚合**：标题相同且同一天发送的汇报，经模型判断正文描述同一事项后合并为一个工作事项
3. **证据分级**：严格按 evidence-rules.md 的四级优先级执行
4. **分配 R 编号**：对去重聚合后的每个独立工作事项，按顺序分配 `R{MM}{序号}` 编号。编号规则：
   - 月份统一两位补零（01-12），序号从 01 开始连续递增
   - 每条编号附带汇报标题全文，格式：`R{编号}`《[汇报标题]》
   - **每条编号必须同时记录汇报链接**，格式：`huibao://view?id={reportId}`（字符串原样，不做任何转换）。聚合场景取按 `createTime` 最早的一条
5. **分配 RP 编号**（上月参考引用）：从 Step 2b 数据中，按 `reports` 列表顺序分配 `RP{序号}` 编号。RP 编号仅用于基线引用和附录 A.3，**不参与**当月证据分级和灯色判断。首月不分配
6. **按节点归集**：利用 `reportTaskMapping` 确定每条汇报关联了哪些节点。交叉引用标注
7. **月份归集口径**：以汇报的发出时间（`businessTime`/`createTime`）为准

将证据台账写入 `/tmp/evidence_ledger_{groupId}.md`，格式为：

```markdown
## 证据台账

### R 编号索引

| R 编号 | 汇报标题 | 证据级别 | 汇报链接 | 关联节点 |
|--------|---------|---------|---------|---------|
| R0301 | 《[汇报标题]》 | 主证据 | [查看汇报](huibao://view?id=xxxxxxxxxxxxx) | 目标X / KRY |
| ... | ... | ... | ... | ... |

### 统计摘要
- 命中原始工作汇报：N 份
- 经批量通知归并后最终采纳：M 份
- 其中本人主证据：X 份、他人手动汇报：Y 份、AI 汇报：Z 份

### 按目标归集（逐 KR/举措明细）

#### 目标 [fullLevelNumber]: [目标名称]

**关键成果：**

| KR 编号 | KR 名称 | 关联 R 编号 | 证据级别分布 | 证据充分性 |
|---------|---------|------------|-------------|-----------|
| [fullLevelNumber] | [名称] | R0301, R0303 | 主证据×2 | 充分 |

**关键举措：**

| 举措编号 | 举措名称 | 关联 R 编号 | 证据级别分布 | 证据充分性 |
|---------|---------|------------|-------------|-----------|
| [fullLevelNumber] | [名称] | R0301 | 主证据×1 | 充分 |
```

**关键要求**：
- 证据台账是最终报告附录的**唯一数据源**，Step 3d 拼接附录时必须直接读取此文件
- "按目标归集"部分是 Step 3c 逐目标处理的**输入索引**

---

## Step 3c: 逐目标精读判断与章节组装

**核心原则**：以目标为维度逐个完成"精读证据 → 判灯 → 写章节"的闭环，避免证据串台。

### 预处理：目标级排除判断（以目标维度为准）

按 [traffic-light-rules.md](traffic-light-rules.md) 的排除规则，**先对所有目标执行排除判断**。只看目标自身的 `planDateRange` 与汇报月份的区间交叉，不单独看其下 KR/举措的时间范围。目标被排除（★未启动）后，其下所有 KR 和举措一律不判断。

仅对通过目标级排除判断（结果为"参与"）的目标，才进一步对其下 KR/举措执行排除判断。

将被排除的节点记录到 `/tmp/excluded_goals_{groupId}.md`：

```markdown
## 本月不参与自查的节点

### 目标级排除（★ 未启动，其下 KR/举措一律不判断）

| 目标名称 | 编号 | 计划时间范围 | 排除原因 |
|---------|------|-------------|---------|
| [名称] | [编号] | [planDateRange] | 目标计划期未覆盖本月 / 草稿 |

### KR/举措级排除（仅针对参与自查的目标下的子节点）

| 节点类型 | 名称 | 编号 | 所属目标 | 计划时间范围 | 排除原因 |
|---------|------|------|---------|-------------|---------|
| 关键成果 | [名称] | [编号] | [目标编号] | [planDateRange] | 计划期未覆盖本月 / 草稿 |
| 关键举措 | [名称] | [编号] | [目标编号] | [planDateRange] | 计划期未覆盖本月 / 草稿 |
```

### 逐目标循环

> **上下文隔离原则**：每个目标的判断完全独立，不继承前一轮目标的上下文。

对每个**参与自查的目标**，按以下 7 步闭环执行：

**(i) 读取该目标的输入**

- **目标数据文件**：直接读取 `/tmp/goal_data_{groupId}_{goalId}.json`
- **锚点**（从 Step 3a）：该目标的名称、编号、衡量标准、KR/举措结构
- **证据子集**（从 Step 3b 的"按目标归集"）：每个 KR/举措关联的 R 编号和证据充分性
- **汇报正文**（从 `uniqueReportMap`）：对超长汇报（>4000字）执行 AI 摘要（控制在 500-800 字，保留关键数据原样）

**(ii) 读取排除状态**

直接从 `/tmp/excluded_goals_{groupId}.md` 读取，**不重复执行排除判断逻辑**。

**(iii) 逐 KR 精读分析（不判灯）**

对每个参与自查的关键成果，精读关联汇报正文，对照衡量标准，生成 KR 分析卡片：

```markdown
### KR卡: [关键成果名称] ([编号])

- 衡量标准：[从 measureStandard 提取]
- 计划时间范围：[planDateRange]
- 本月主证据：[R编号列表]
- 本月辅证：[R编号列表]
- 距离衡量标准的差距：[基于证据判断]
- 判断理由：[详细分析]
```

**(iv) 逐举措精读判灯**

对每个参与自查的关键举措，**严格按 traffic-light-rules.md 判灯**，生成举措卡片：

```markdown
### Action卡: [举措名称] ([编号])

- 计划时间范围：[planDateRange]
- 当前状态：[statusDesc]
- 本月推进动作：[从证据提取，引用R编号]
- 对关键成果的支撑情况：[强/中/弱]
- 灯色判断：[🟢/🟡/🔴/⚫]
- 判断依据：
```

**(v) 聚合目标级灯色**

从举措灯色聚合，按优先级命中即停：有红则红 → 有黄则黄 → 有黑则黑 → 全绿则绿。

**(vi) 组装目标报告章节**

**严格按 [report-template-bp-self-check.md](report-template-bp-self-check.md) 模板输出**，包含 4 个必需子章节：承诺与实际对照、关键成果达成与举措推进、偏差问题与原因分析、目标级综合灯色结论。

**(vii) 写入文件**

- 判断卡片（过程记录）：`/tmp/goal_cards_{groupId}_{goalIndex}.md`
- 报告章节（搬入最终报告）：`/tmp/goal_section_{groupId}_{goalIndex}.md`

---

## Step 3d: 报告拼接与合规性校验

> **加载校验规则**：进入 Step 3d 前，读取 [validation-rules.md](validation-rules.md)。

### (i) 聚合灯色统计

读取所有 `/tmp/goal_section_{groupId}_{goalIndex}.md`，提取灯色结论，分两部分统计：
1. **参与自查的目标**：统计绿/黄/红/黑灯数量
2. **★ 未启动的目标**：单独统计个数，不计入四色灯

### (ii) 生成全局章节

**严格按 [report-template-bp-self-check.md](report-template-bp-self-check.md) 逐字段对照组装**：

1. **元数据头**：周期、员工姓名、基线引用（RP 编号超链接，若首月写"首月，无基线"）、证据说明
2. **第 1 章 总体自查结论**：1.1 结论 + 1.2 灯色分布概览 + 1.3 偏差点
3. **第 2 章 目标级自查明细**：2.1 总览表（7 列，含排除目标）+ 2.2 目标明细（从各章节文件拼接）
4. **第 3 章 年度结果预判评分**：仅输出一个链接 `[点击进入本月：年度结果预判评分](https://sg-al-cwork-web.mediportal.com.cn/BP-manager/web/dist/#/monthly-review/self?groupId={groupId}&month={month})`
5. **附录**：从 `/tmp/evidence_ledger_{groupId}.md` 直接读取原样搬入 A.1 + A.2 + A.3

### (iii) 语言清洗

**严格按 [validation-rules.md](validation-rules.md) 第三章执行。**

### (iv) 写入最终报告

写入 `/tmp/report_selfcheck_{groupId}.md`。

### (v) 合规性校验

**严格按 [validation-rules.md](validation-rules.md) 第一章执行 15 项校验清单。** 全部通过后方可进入发送流程。

---

## Step 4: 发送 → 保存

**校验通过后直接发送**，无需等待用户确认。

### 发送报告

```bash
python3 .openclaw/skills/bp-monthly-report/scripts/monthly_report_api.py send_report \
  --receiver_emp_id "{employeeId}" \
  --title "{员工姓名} {YYYY年M月} BP自查报告" \
  --content_file "/tmp/report_selfcheck_{groupId}.md"
```

> `--sender_id` 无需手动指定。脚本自动通过接收人的 empId 查询组织架构获取 corpId，匹配对应企业的 AI 助理。

记录返回的 `data.id` → 记为 `report_record_id`，生成报告链接：`huibao://view?id={report_record_id}`

### 保存到 BP 系统

```bash
python3 .openclaw/skills/bp-monthly-report/scripts/monthly_report_api.py save_monthly_report \
  --group_id "{groupId}" \
  --month "{YYYY-MM}" \
  --content_file "/tmp/report_selfcheck_{groupId}.md" \
  --report_record_id "{report_record_id}"
```

`save_monthly_report` 默认将 `generateStatus` 设为 `1=成功`，保存成功即代表流程完成，**无需再单独调用 `update_report_status --status 1`**。

### 失败处理

若任何步骤失败，必须立即更新状态为"失败"并记录原因：

```bash
python3 .openclaw/skills/bp-monthly-report/scripts/monthly_report_api.py update_report_status \
  --group_id "{groupId}" \
  --month "{YYYY-MM}" \
  --status 2 \
  --fail_reason "具体失败原因描述"
```

---

## 工具脚本速查表

```bash
python3 .openclaw/skills/bp-monthly-report/scripts/monthly_report_api.py <action> [options]
```

| action | 说明 | 必填参数 | 可选参数 |
|--------|------|----------|----------|
| `collect_monthly_overview` | 采集全局概览（Step 2a-i） | `--group_id`、`--month` | `--output` |
| `collect_goal_data` | 按目标采集详情+汇报原文（Step 2a-ii） | `--goal_id`、`--month` | `--group_id`、`--output` |
| `collect_monthly_data` | [旧版] 一次性采集全量数据到单个 JSON | `--group_id`、`--month` | `--output` |
| `collect_previous_month_data` | 采集上月汇报+评价作为参考基线 | `--group_id`、`--month`（上月YYYY-MM） | `--output` |
| `get_report_content` | 获取单条汇报正文内容 | `--report_id` | 无 |
| `send_report` | 发送报告（工作协同） | `--receiver_emp_id`、`--title`、`--content_file` | `--sender_id` |
| `save_monthly_report` | 保存月报到 BP 系统 | `--group_id`、`--month`、`--content_file`、`--report_record_id` | 无 |
| `update_report_status` | 更新月报生成状态（0=生成中, 1=成功, 2=失败） | `--group_id`、`--month`、`--status` | `--fail_reason`（status=2 时必填） |

---

## 通用约束

- 所有 ID 参数保持字符串原样传递，**严禁 parseInt 或 Number 转换**
- **严禁测试发送**：`send_report` 会真实推送给员工，只有报告内容完整生成且合规性校验全部通过后才能调用
- **校验通过后直接发送**，不再等待用户确认
- **禁止一步生成整篇报告**，必须走 3a → 3b → 3c → 3d 四步
- 发送报错重试：脚本对"汇报人ID有误"和 `resultCode=401` 自动等待 60 秒后重试一次
- 发送人和 appKey 根据接收人企业自动匹配（corpId → sender + appKey 映射已内置在脚本中），查询数据使用用户提供的 key（`BP_OPEN_API_APP_KEY`），发送汇报使用与 sender 对应的机器人 key
- 汇报接收人是员工本人（`employeeId`），**不是** `groupId`

---

## 批量生成

1. `get_all_periods` → 获取启用周期
2. `get_group_tree --only_personal` → 获取所有个人分组
3. 遍历每个个人分组，对每人执行完整生成流程

**注意**：批量生成前必须征得用户明确同意，并告知预计耗时。

---

## 环境配置

复用 `bp-data-viewer` 的环境变量：

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `BP_OPEN_API_APP_KEY` | 数据查询用 API 密钥（**必填**） | 无（用户提供） |
| `BP_OPEN_API_BASE_URL` | API 地址 | `https://sg-al-cwork-web.mediportal.com.cn/open-api` |

> 发送汇报的机器人 appKey 已按 sender（400001/400002/400003）内置在脚本中，根据接收人企业自动匹配，无需配置。

---

## 错误处理

- BP 数据获取失败时，提示用户检查 `BP_OPEN_API_APP_KEY` 配置
- 报告发送失败时，保留报告文件，提示用户可手动重试
- 脚本自动处理"汇报人ID有误"或 401 限流的重试；若重试仍失败，保留报告内容并提示用户排查
- 某个目标下无汇报数据时，在报告中标注"本月暂未收到工作汇报"并按灯色规则判断，不中断整体流程
